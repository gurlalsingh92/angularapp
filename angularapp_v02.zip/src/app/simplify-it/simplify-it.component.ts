import { Component } from '@angular/core';

@Component({
  selector: 'app-simplify-it',
  standalone: true,
  imports: [],
  templateUrl: './simplify-it.component.html',
  styleUrl: './simplify-it.component.scss'
})
export class SimplifyItComponent {

}
