import { Component } from '@angular/core';

@Component({
  selector: 'app-working-at-dcg',
  standalone: true,
  imports: [],
  templateUrl: './working-at-dcg.component.html',
  styleUrl: './working-at-dcg.component.scss'
})
export class WorkingAtDcgComponent {

}
