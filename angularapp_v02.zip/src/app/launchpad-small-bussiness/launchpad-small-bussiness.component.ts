import { Component } from '@angular/core';

@Component({
  selector: 'app-launchpad-small-bussiness',
  standalone: true,
  imports: [],
  templateUrl: './launchpad-small-bussiness.component.html',
  styleUrl: './launchpad-small-bussiness.component.scss'
})
export class LaunchpadSmallBussinessComponent {

}
